package com.example.proiectfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProiectFinalApplicationTests {

    @Test
    void contextLoads() {
    }

}
